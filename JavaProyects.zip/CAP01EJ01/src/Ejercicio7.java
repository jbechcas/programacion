public class Ejercicio7 {
    public static void main(String[] args) {
        System.out.printf("%18s %n","*");
        System.out.printf("%17s %1s %n","*","*");
        System.out.printf("%16s %3s %n","*","*");
        System.out.printf("%15s %5s %n","*","*");
        System.out.printf("%22s%n","*********");
    }
}
