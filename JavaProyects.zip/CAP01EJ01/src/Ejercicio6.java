public class Ejercicio6 {
    public static void main(String[] args) {
        System.out.printf("%18s %n","*");
        System.out.printf("%19s %n","***");
        System.out.printf("%20s %n","*****");
        System.out.printf("%21s %n","*******");
        System.out.printf("%22s%n","*********");
    }
}