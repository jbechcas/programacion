public class Ejercicio3 {
    public static void main(String[] args) {
        System.out.printf("%-12s%-12s%n","computer","ordenador");
        System.out.printf("%-12s%-12s%n","student","estudiante"); 
        System.out.printf("%-12s%-12s%n","cat","gato"); 
        System.out.printf("%-12s%-12s%n","penguin","pingüino"); 
        System.out.printf("%-12s%-12s%n","machine","máquina"); 
        System.out.printf("%-12s%-12s%n","nature","naturaleza"); 
        System.out.printf("%-12s%-12s%n","light","luz"); 
        System.out.printf("%-12s%-12s%n","green","verde"); 
        System.out.printf("%-12s%-12s%n","book","libro"); 
        System.out.printf("%-12s%-12s%n","pyramid","pirámide");        
    }
}
