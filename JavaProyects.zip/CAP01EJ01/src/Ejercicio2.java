public class Ejercicio2 {
    public static void main(String[] args) {
        System.out.println("Jorge Bech Castillo");
        System.out.println("C/Tenerife Nº1,bloque 1,1k");
        System.out.println("633697546");
    }
}
