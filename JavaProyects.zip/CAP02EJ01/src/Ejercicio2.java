public class Ejercicio2 {
    public static void main(String[] args) {
        String nombre;
        nombre = "Jorge Bech Castillo";
        System.out.print(nombre);
    }
}
