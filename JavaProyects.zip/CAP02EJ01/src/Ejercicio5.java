public class Ejercicio5 {
    public static void main(String[] args) {
        double euros,resultado;
        double pesetas;
        pesetas = 10000;
        euros = 166;
        resultado = ((int)(pesetas/euros));
        System.out.print((double)resultado+"€");
    }
}