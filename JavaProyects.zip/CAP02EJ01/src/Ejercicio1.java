public class Ejercicio1 {
    public static void main(String[] args) throws Exception {
        int x, y;
        x = 999;
        y = 144;
        System.out.println("La suma de "+x+"+"+y+"="+(x+y));
        System.out.println("La resta de "+x+"-"+y+"="+(x-y));
        System.out.println("La multiplicación de "+x+"+"+y+"="+(x+y));
        System.out.println("La división de "+x+"/"+y+"="+((double)x/(double)y));
    }
}

