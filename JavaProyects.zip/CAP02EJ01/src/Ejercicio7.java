public class Ejercicio7 {
    public static void main(String[] args) {
    char char1 = 'a';
    char char2 = 'b';
    String string1 = "gato";
    String string2 = "perro";
    System.out.println(""+char1+char2+string1+string2);
    }
}
