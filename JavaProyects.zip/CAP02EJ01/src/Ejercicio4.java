public class Ejercicio4 {
    public static void main(String[] args) {
        double euros,resultado;
        int pesetas;
        pesetas = 166;
        euros = 900;
        resultado = (euros*pesetas);
        System.out.print((double)resultado+"€");
    }
}
