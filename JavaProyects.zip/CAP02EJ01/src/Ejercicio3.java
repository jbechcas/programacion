public class Ejercicio3 {
    public static void main(String[] args) {
        String nombre, direccion, telefono;
        nombre = "Jorge Bech Castillo";
        direccion = "C/Tenerife Nº1,bloque 1, 1k";
        telefono = "633 69 75 46";
        System.out.println(nombre);
        System.out.println(direccion);
        System.out.println(telefono);
    }
}